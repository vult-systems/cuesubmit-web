#  Copyright Contributors to the OpenCue Project
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""User activity detection for CueNIMBY.

Monitors keyboard and mouse activity to automatically lock/unlock
the host for rendering based on user presence.
"""

import logging
import threading
import time
from typing import Optional, Callable

logger = logging.getLogger(__name__)


class ActivityDetector:
    """Monitors user input activity via keyboard and mouse.
    
    When user activity is detected, calls the on_activity_detected callback.
    When the user has been idle for idle_threshold seconds, calls on_idle callback.
    """

    def __init__(
        self,
        idle_threshold: int = 120,
        check_interval: int = 10
    ):
        """Initialize activity detector.
        
        Args:
            idle_threshold: Seconds of idle time before considering user inactive.
            check_interval: Seconds between idle checks.
        """
        self.idle_threshold = idle_threshold
        self.check_interval = check_interval
        
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._mouse_listener = None
        self._keyboard_listener = None
        
        self._last_activity_time = time.time()
        self._is_user_active = False
        self._lock = threading.Lock()
        
        # Callbacks
        self._on_activity_detected: Optional[Callable[[], None]] = None
        self._on_idle: Optional[Callable[[], None]] = None
        
        # Try to import pynput
        self._pynput_available = False
        try:
            import pynput
            self._pynput = pynput
            self._pynput_available = True
            logger.info("pynput available for activity detection")
        except ImportError:
            logger.warning("pynput not available - activity detection disabled")
    
    @property
    def is_available(self) -> bool:
        """Check if activity detection is available."""
        return self._pynput_available
    
    @property
    def is_user_active(self) -> bool:
        """Check if user is currently active."""
        with self._lock:
            return self._is_user_active
    
    def _on_interaction(self, *args) -> None:
        """Handle keyboard/mouse interaction event."""
        with self._lock:
            was_idle = not self._is_user_active
            self._last_activity_time = time.time()
            self._is_user_active = True
            
        if was_idle:
            logger.info("User activity detected - was idle")
            if self._on_activity_detected:
                try:
                    self._on_activity_detected()
                except Exception as e:
                    logger.error(f"Error in activity callback: {e}")
    
    def _check_idle(self) -> None:
        """Check if user has been idle long enough."""
        with self._lock:
            if not self._is_user_active:
                return
            
            idle_time = time.time() - self._last_activity_time
            if idle_time >= self.idle_threshold:
                self._is_user_active = False
                was_active = True
            else:
                was_active = False
        
        if was_active:
            logger.info(f"User idle for {self.idle_threshold}s")
            if self._on_idle:
                try:
                    self._on_idle()
                except Exception as e:
                    logger.error(f"Error in idle callback: {e}")
    
    def _idle_check_loop(self) -> None:
        """Background thread that periodically checks for idle state."""
        while self._running:
            try:
                self._check_idle()
            except Exception as e:
                logger.error(f"Error in idle check loop: {e}")
            time.sleep(self.check_interval)
    
    def start(
        self,
        on_activity_detected: Optional[Callable[[], None]] = None,
        on_idle: Optional[Callable[[], None]] = None
    ) -> bool:
        """Start activity detection.
        
        Args:
            on_activity_detected: Callback when user activity is detected.
            on_idle: Callback when user becomes idle.
            
        Returns:
            True if started successfully, False if pynput not available.
        """
        if not self._pynput_available:
            logger.warning("Cannot start activity detection - pynput not available")
            return False
        
        if self._running:
            logger.warning("Activity detection already running")
            return True
        
        self._on_activity_detected = on_activity_detected
        self._on_idle = on_idle
        self._running = True
        
        # Reset state
        self._last_activity_time = time.time()
        self._is_user_active = False
        
        # Start input listeners
        try:
            self._mouse_listener = self._pynput.mouse.Listener(
                on_move=self._on_interaction,
                on_click=self._on_interaction,
                on_scroll=self._on_interaction
            )
            self._keyboard_listener = self._pynput.keyboard.Listener(
                on_press=self._on_interaction
            )
            
            self._mouse_listener.start()
            self._keyboard_listener.start()
            
            # Start idle check thread
            self._thread = threading.Thread(target=self._idle_check_loop, daemon=True)
            self._thread.start()
            
            logger.info("Activity detection started")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start activity detection: {e}")
            self._running = False
            return False
    
    def stop(self) -> None:
        """Stop activity detection."""
        self._running = False
        
        if self._mouse_listener:
            try:
                self._mouse_listener.stop()
            except Exception as e:
                logger.error(f"Error stopping mouse listener: {e}")
            self._mouse_listener = None
        
        if self._keyboard_listener:
            try:
                self._keyboard_listener.stop()
            except Exception as e:
                logger.error(f"Error stopping keyboard listener: {e}")
            self._keyboard_listener = None
        
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
        
        logger.info("Activity detection stopped")
    
    def update_settings(
        self,
        idle_threshold: Optional[int] = None,
        check_interval: Optional[int] = None
    ) -> None:
        """Update detection settings.
        
        Args:
            idle_threshold: New idle threshold in seconds.
            check_interval: New check interval in seconds.
        """
        if idle_threshold is not None:
            self.idle_threshold = idle_threshold
            logger.info(f"Idle threshold updated to {idle_threshold}s")
        
        if check_interval is not None:
            self.check_interval = check_interval
            logger.info(f"Check interval updated to {check_interval}s")
